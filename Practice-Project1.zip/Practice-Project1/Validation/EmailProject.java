package Validation;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.*;
public class EmailProject{
 
    public static void main(String[] args) 
    { 
     
      ArrayList<String> list= new ArrayList<String>();
     // String[] strArray = new String[6];
      list.add("praveenaaron130@gmail.com");
      list.add("rakesh@gmail.com"); 
      list.add("sharma@gmail.com"); 
      list.add("kamal@gmail.com"); 
      list.add("poonguzhali@gmail.com");
      list.add("yashu@gmail.com"); 
      
    
        
      String searchElement;
      System.out.println("E-mail: ");
      Scanner scanner = new Scanner(System.in);
      searchElement = scanner.nextLine();
      String regex = "^(.+)@(.+)$";
      Matcher matcher = Pattern.compile(regex).matcher(searchElement);
      if (matcher.matches() && list.stream().anyMatch(mail -> mail.equals(searchElement))) {
          System.out.println(searchElement + " = is present");
      } else {
          System.out.println("Not a valid or is not present");
      }
      scanner.close();
                   }
    
    }